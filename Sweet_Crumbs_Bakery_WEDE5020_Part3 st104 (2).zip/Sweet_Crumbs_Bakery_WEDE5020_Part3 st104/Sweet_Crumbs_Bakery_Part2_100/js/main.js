/* Sweet Crumbs Bakery | Part 3 interactions
 * Static-site form handling uses a mailto draft because no server/email service credentials
 * are supplied. The visitor reviews and sends the email from their own email application.
 */
(() => {
  "use strict";

  const EMAIL_TO = "hello@sweetcrumbsbakery.co.za";

  document.querySelectorAll("[data-current-year]").forEach((node) => {
    node.textContent = String(new Date().getFullYear());
  });

  // Clear, accessible inline validation messages.
  function showStatus(form, message, type) {
    const status = form.querySelector(".form-status");
    if (!status) return;
    status.textContent = message;
    status.className = "form-status " + (type || "");
    status.setAttribute("role", type === "error" ? "alert" : "status");
  }

  function validateForm(form) {
    let firstInvalid = null;
    form.querySelectorAll("[required]").forEach((field) => {
      field.setCustomValidity("");
      const value = field.value.trim();
      if (!value) {
        field.setCustomValidity("Please complete this field.");
      } else if (field.type === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value)) {
        field.setCustomValidity("Please enter a valid email address.");
      } else if (field.type === "tel" && !/^[+0-9() -]{7,20}$/.test(value)) {
        field.setCustomValidity("Enter a valid phone number using digits, spaces, brackets or +.");
      } else if (field.minLength > 0 && value.length < field.minLength) {
        field.setCustomValidity(`Please enter at least ${field.minLength} characters.`);
      } else if (field.maxLength > 0 && value.length > field.maxLength) {
        field.setCustomValidity(`Please use no more than ${field.maxLength} characters.`);
      }
      if (!field.checkValidity() && !firstInvalid) firstInvalid = field;
    });
    // Validate optional controls that have constraints too (for example, collection date).
    form.querySelectorAll("input:not([required]), textarea:not([required]), select:not([required])").forEach((field) => {
      if (field.type === "date" && field.value && field.min && field.value < field.min) {
        field.setCustomValidity("Please choose a date that is not in the past.");
      } else if (field.type !== "date") {
        field.setCustomValidity("");
      }
      if (!field.checkValidity() && !firstInvalid) firstInvalid = field;
    });
    if (firstInvalid) {
      firstInvalid.reportValidity();
      firstInvalid.focus();
      showStatus(form, firstInvalid.validationMessage || "Please check the highlighted fields and try again.", "error");
      return false;
    }
    return true;
  }

  document.querySelectorAll(".js-email-form").forEach((form) => {
    form.querySelectorAll("input, textarea, select").forEach((field) => {
      field.addEventListener("input", () => {
        field.setCustomValidity("");
        if (field.checkValidity()) field.removeAttribute("aria-invalid");
      });
    });
    form.addEventListener("reset", () => {
      window.setTimeout(() => showStatus(form, "Form cleared. You can start again.", "info"), 0);
    });
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!validateForm(form)) {
        form.querySelectorAll(":invalid").forEach((field) => field.setAttribute("aria-invalid", "true"));
        return;
      }
      const data = new FormData(form);
      const isCake = form.dataset.formType === "cake";
      const subject = isCake ? "Custom cake enquiry - Sweet Crumbs Bakery" : `Website enquiry: ${data.get("subject")}`;
      const lines = [];
      data.forEach((value, key) => {
        if (String(value).trim()) lines.push(`${key.replace(/[-_]/g, " ")}: ${String(value).trim()}`);
      });
      lines.push("", "Sent from the Sweet Crumbs Bakery website form.");
      const mailto = `mailto:${EMAIL_TO}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(lines.join("\n"))}`;
      showStatus(form, "Your details are ready. Your email application should open with a draft. Review it and press Send to submit your enquiry. If it does not open, email hello@sweetcrumbsbakery.co.za directly.", "success");
      const link = document.createElement("a");
      link.href = mailto;
      link.className = "button primary email-draft-link";
      link.textContent = "Open email draft";
      link.setAttribute("aria-label", "Open a pre-filled email draft to Sweet Crumbs Bakery");
      const oldLink = form.querySelector(".email-draft-link");
      if (oldLink) oldLink.remove();
      const row = form.querySelector(".button-row");
      if (row) row.appendChild(link);
      // Attempt to open the visitor's configured email application; the visible link is a fallback.
      window.location.href = mailto;
    });
  });

  // Product/menu search: filter menu rows and menu cards live without reloading the page.
  const search = document.getElementById("menu-search");
  const clearSearch = document.getElementById("clear-menu-search");
  const searchStatus = document.getElementById("menu-search-status");
  if (search) {
    const searchableSections = Array.from(document.querySelectorAll(".menu-searchable"));
    const entries = [];
    searchableSections.forEach((section) => {
      section.querySelectorAll("tbody tr, .info-card").forEach((item) => {
        entries.push({ item, section, text: item.textContent.toLocaleLowerCase() });
      });
    });
    const updateSearch = () => {
      const term = search.value.trim().toLocaleLowerCase();
      let visible = 0;
      entries.forEach(({ item, text }) => {
        const match = !term || text.includes(term);
        item.hidden = !match;
        if (match) visible++;
      });
      searchableSections.forEach((section) => {
        const sectionHasMatch = Array.from(section.querySelectorAll("tbody tr, .info-card")).some((item) => !item.hidden);
        section.hidden = !sectionHasMatch;
      });
      if (searchStatus) searchStatus.textContent = term
        ? `${visible} menu item${visible === 1 ? "" : "s"} match “${search.value.trim()}”.`
        : "Showing all menu items.";
    };
    search.addEventListener("input", updateSearch);
    clearSearch?.addEventListener("click", () => {
      search.value = "";
      updateSearch();
      search.focus();
    });
  }
})();
