# Part 2 Change Log — Sweet Crumbs Bakery

## Improvements made after Part 1
1. Reworked the visual identity using a stronger navy/charcoal/blue/orange palette to match the requested slightly boyish design direction.
2. Reorganised the website into a clear folder structure with a dedicated `css` folder and `assets` folder.
3. Added one shared external CSS file and linked every HTML page to it.
4. Rebuilt the navigation as a consistent, accessible navigation component with an active-page state.
5. Added semantic HTML5 layout elements: `header`, `nav`, `main`, `section`, `article`, `aside`, `figure`, `figcaption` and `footer`.
6. Expanded page content so each page has meaningful, relevant information rather than placeholder text.
7. Improved the product menu with a structured table, caption, table headings and responsive table wrapper.
8. Improved forms with fieldsets, legends, labels, suitable input types, autocomplete and clear/reset controls.
9. Added descriptive alternative text to all gallery images.
10. Added decorative, typographic and layout CSS including spacing, borders, shadows, typography, grids, buttons, cards and responsive images.
11. Added the required media query below 960px.
12. Added a second 560px breakpoint for smaller portrait phones.
13. Made navigation, forms and buttons touch-friendly at mobile widths.
14. Used fluid widths and responsive grids to avoid page-level horizontal scrolling.
15. Added visible keyboard focus states for interactive elements.
16. Added README, sitemap, testing checklist, GitHub commit plan and this detailed change log.

## Part 2 scope boundary
JavaScript functionality, SEO implementation and Google Form integration are intentionally reserved for Part 3.
