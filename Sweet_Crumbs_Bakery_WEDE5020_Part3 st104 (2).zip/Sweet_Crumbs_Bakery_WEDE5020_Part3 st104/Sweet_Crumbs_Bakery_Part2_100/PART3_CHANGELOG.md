# Part 3 Changelog — Sweet Crumbs Bakery

## Version 3.0 — Website functionality and form improvements
### Added
- Shared JavaScript file at `js/main.js`.
- Client-side contact and custom-cake enquiry validation.
- Accessible inline success, information and error messages.
- Email-draft processing with a visible fallback link.
- Live menu search for product rows and product cards.
- Dynamic current year in the footer.
- Page-specific SEO keyword and robots metadata.
- Skip-to-main-content link and accessible live status regions.
- Part 3 testing and deployment guide.

### Changed
- Replaced Part 2 placeholder form instructions with clear Part 3 behaviour.
- Added length limits and phone/date constraints to relevant form controls.
- Updated README for Part 3 structure, functionality, testing and known limitations.
- Added descriptive page-specific meta descriptions.

### Known limitations
- The website is static. The forms do not automatically transmit data to a server or confirm email delivery. They prepare a draft in the visitor's email application. Production email processing requires a configured backend or form service.
- Prices, contact details and location are illustrative academic content and should be verified before a real business launch.
- The project files and commit plan are provided, but the student must create/push actual GitHub commits and capture evidence in their own account.
