# Part 2 Design Notes

The website uses a bold, slightly boyish visual direction while remaining appropriate for a bakery: dark navy/charcoal surfaces, electric blue links and orange accents. The layout uses CSS Grid and Flexbox, with shared selectors to demonstrate the cascading nature of CSS.

## Finalisation note
The shared CSS and page templates were reviewed after the first build.
