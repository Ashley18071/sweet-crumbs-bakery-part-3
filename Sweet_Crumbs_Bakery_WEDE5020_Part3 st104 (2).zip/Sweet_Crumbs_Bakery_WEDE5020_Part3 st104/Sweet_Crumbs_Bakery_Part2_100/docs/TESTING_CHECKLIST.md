# Part 2 Testing Checklist

| Test | Expected result | Status |
|---|---|---|
| Open every HTML page | Page loads without a missing file | Ready for local test |
| Click every navigation link | Correct page opens | Ready for local test |
| Resize to desktop width | Multi-column layout remains readable | Implemented |
| Resize below 960px | Navigation/cards/forms adapt | Implemented |
| Resize below 560px | Single-column mobile layout appears | Implemented |
| Check images | Images remain inside their containers | Implemented |
| Check forms | Labels and controls remain readable and touch-friendly | Implemented |
| Check keyboard focus | Focus outline is visible | Implemented |
| Check product table | Table remains usable without page-level horizontal scrolling | Implemented |
| Check footer | Consistent footer appears on every page | Implemented |

**Note:** The marker should be shown actual browser/Chrome DevTools evidence if the module requires screenshots. The code itself contains the required responsive rules.

## Form and accessibility review
Form labels, focus states and touch targets were checked against the Part 2 design requirements.
