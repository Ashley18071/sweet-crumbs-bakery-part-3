# Responsive Evidence Guide

For submission evidence, open the site in Chrome DevTools and test a desktop viewport, a tablet/portrait viewport below 960px and a small phone viewport below 560px. Capture screenshots showing the full page width, navigation, cards, form and product table.
