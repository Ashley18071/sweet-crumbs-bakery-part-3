# Part 3 Testing and Deployment Guide

## Test environment
- Recommended: current Chrome, Edge, Firefox or Safari.
- Run by opening `index.html` or through Visual Studio Code Live Server.
- Check the browser developer console for JavaScript errors.

## Functional test cases
| ID | Test | Expected result |
|---|---|---|
| T01 | Open each of the seven HTML pages | Page loads and shared navigation is present |
| T02 | Follow each navigation link | Correct page opens; active page is indicated |
| T03 | Leave contact name empty and submit | Submission is blocked and a required-field message is shown |
| T04 | Enter malformed contact email | Submission is blocked with email validation feedback |
| T05 | Enter a too-short subject or message | Submission is blocked by length validation |
| T06 | Complete contact form with valid data | Email draft opens or fallback link appears; no false claim that email was sent |
| T07 | Submit custom-cake form without required values | Submission is blocked with validation feedback |
| T08 | Enter invalid phone number | Submission is blocked with phone guidance |
| T09 | Select a collection date earlier than the minimum | Browser/JavaScript validation blocks the form |
| T10 | Complete custom-cake enquiry | A pre-filled custom cake email draft is prepared |
| T11 | Search `chocolate` on Products & Menu | Matching product entries remain visible and match count updates |
| T12 | Search for a term with no matches | Search reports zero matches and matching menu sections hide |
| T13 | Select Clear search | All menu entries return |
| T14 | Reset a form | Fields clear and an informational status is shown |
| T15 | Check footer year | Year matches the current year |
| T16 | Use Tab and Shift+Tab | Controls are keyboard reachable and focus is visible |
| T17 | Test 320px, 560px, tablet and desktop widths | Layout adapts without unexpected page-level horizontal scrolling |
| T18 | Inspect SEO on every page | Unique title and description plus keywords metadata exist |
| T19 | Inspect gallery images | Descriptive filenames, alt text, dimensions and lazy loading exist |
| T20 | Test email draft fallback | Link points to the configured academic recipient address |

## Manual test record
Record actual results, browser, date and screenshots when testing. Do not mark tests as passed until you have performed them on your device.

| Test ID | Actual result (Pass/Fail) | Evidence / notes |
|---|---|---|
| T01-T05 | To be completed by student | |
| T06-T10 | To be completed by student | |
| T11-T15 | To be completed by student | |
| T16-T20 | To be completed by student | |

## Deployment checklist
- [ ] Confirm the real business name, email address, phone number, location and prices.
- [ ] Decide on a secure form-processing service or backend if automatic collection is required.
- [ ] Add privacy information and consent where appropriate before collecting personal data.
- [ ] Test all pages and forms in current browsers.
- [ ] Create a GitHub repository under the student's account.
- [ ] Commit in descriptive stages and push the commits.
- [ ] Capture genuine screenshots of GitHub history and working website behaviour.
- [ ] Verify the deployed site and all relative asset paths.
