# Sweet Crumbs Bakery — Sitemap

```text
Home
├── About Us
├── Products & Menu
├── Custom Cakes
├── Gallery
├── Special Offers
└── Contact Us
```

## Page purpose
- **Home:** brand introduction, featured products, location and calls to action.
- **About Us:** bakery purpose, values, target users and website goal.
- **Products & Menu:** cakes, cupcakes, pastries and bread with starting prices.
- **Custom Cakes:** occasion information and customer enquiry form.
- **Gallery:** visual product examples with captions and alt text.
- **Special Offers:** promotional and seasonal content.
- **Contact Us:** contact details and general enquiry form.

## Navigation review
All seven pages use the same navigation order and active-page state.
