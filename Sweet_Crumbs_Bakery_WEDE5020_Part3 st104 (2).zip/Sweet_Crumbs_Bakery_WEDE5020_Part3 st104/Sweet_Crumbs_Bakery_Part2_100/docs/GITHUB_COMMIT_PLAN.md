# GitHub Commit Plan — Part 3

Create these as separate, real commits in the Git repository. Do not submit this list as if it were actual commit history.

1. `Document Part 3 requirements and website structure`
2. `Add page-specific SEO metadata across website`
3. `Implement shared JavaScript form validation`
4. `Add accessible contact form status and email draft handling`
5. `Add custom cake enquiry validation and email draft`
6. `Implement live menu search and clear control`
7. `Add dynamic footer year and skip navigation link`
8. `Document Part 3 tests and known static-site limitations`
9. `Update README and changelog for Part 3`
10. `Run final cross-page and responsive checks`

Example workflow:
```bash
git status
git add README.md PART3_CHANGELOG.md docs/ js/ css/ *.html
git commit -m "Implement Part 3 website functionality"
git push
```

For stronger evidence, split the staged changes into multiple commits matching the sequence above. Only claim commits that exist in the actual repository. The student must create the remote repository, push their work and capture screenshots from their GitHub account.
