# Sweet Crumbs Bakery — WEDE5020 POE Part 3

## Project overview
Sweet Crumbs Bakery is a hypothetical bakery website concept for Nelspruit CBD, Mpumalanga, South Africa. Part 3 extends the Part 2 HTML/CSS website with JavaScript interactions, live product search, improved form validation and feedback, page-level SEO metadata, and submission documentation.

> **Important implementation note:** This is a static HTML/CSS/JavaScript project. It does not have a server or a configured transactional email provider. Contact and custom-cake forms validate the visitor's input and prepare a pre-filled email using the visitor's email application (`mailto:`). The visitor must review and send the draft. This is clearly communicated on the forms. To collect submissions automatically in production, connect a secure server-side endpoint or a form service and configure it with the owner's consent and credentials.

## Pages
- `index.html` — Home
- `about.html` — About Us
- `products.html` — Products & Menu, including live search
- `custom-cakes.html` — Custom Cake Enquiry
- `gallery.html` — Gallery
- `offers.html` — Special Offers
- `contact.html` — Contact details and General Contact Form

## Folder structure
```text
Sweet_Crumbs_Bakery_Part2_100/
├── index.html
├── about.html
├── products.html
├── custom-cakes.html
├── gallery.html
├── offers.html
├── contact.html
├── css/style.css
├── js/main.js
├── assets/
│   ├── chocolate-cake.svg
│   ├── cupcakes.svg
│   └── pastries.svg
├── docs/
│   ├── SITEMAP.md
│   ├── TESTING_CHECKLIST.md
│   ├── RESPONSIVE_EVIDENCE_GUIDE.md
│   ├── PART2_DESIGN_NOTES.md
│   ├── GITHUB_COMMIT_PLAN.md
│   └── PART3_TESTING_AND_DEPLOYMENT.md
├── PART2_CHANGELOG.md
├── PART3_CHANGELOG.md
└── README.md
```

## Part 3 functionality
### GitHub documentation
- This README explains the project, pages, features, testing and static-form limitation.
- `PART3_CHANGELOG.md` records the Part 3 changes.
- `docs/GITHUB_COMMIT_PLAN.md` contains a suggested sequence of descriptive commits.
- A real GitHub repository and real commits must be created/pushed from the student's GitHub account; documentation cannot substitute for repository evidence.

### Contact form and email processing
- Required field checks, email format checks, minimum/maximum lengths, phone number format validation and clear inline feedback.
- Invalid fields receive focus and browser validation feedback.
- A successful form prepares an email draft addressed to `hello@sweetcrumbsbakery.co.za`.
- A visible **Open email draft** fallback link is added in case the browser does not open the email app.
- The site does not claim that an email has been sent automatically.

### Website functionality
- Products & Menu page has a live search field.
- Search filters menu table rows and product cards while typing, and reports the number of matches.
- Clear search resets the menu.
- Footer year updates automatically through JavaScript.

### SEO and accessibility
- Each page has a descriptive title, meta description, meta keywords, author and robots metadata.
- Gallery images have meaningful alternative text, descriptive filenames and intrinsic dimensions.
- Semantic headings, navigation labels, skip link, keyboard focus styles, form labels, fieldsets and live status regions support accessibility.

## Running the site
1. Extract the ZIP file.
2. Open `index.html` in a modern browser, or use Visual Studio Code with the Live Server extension.
3. Test every navigation link, the product search, contact form and custom-cake enquiry form.
4. Use a browser console to check for JavaScript errors.
5. Test at desktop and mobile widths.

## Email setup for a real business
The displayed email address is a placeholder for this academic concept. Confirm the real recipient address before deployment. For server-side processing, use a trusted form endpoint or backend (with server-side validation, spam protection and privacy notice). Never place email service passwords, API keys or private credentials in client-side JavaScript.

## Suggested GitHub workflow
See `docs/GITHUB_COMMIT_PLAN.md`. Commit the work in logical stages and push it to a repository created under your own account. Add screenshots or a deployed URL only after you have generated real evidence.
